package game;

public interface EndCondition {

    public boolean check();
}
