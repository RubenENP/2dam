package game;

public enum Domain {NONE, ELECTRICITY, ENERGY, FIRE, LIFE, AIR}
