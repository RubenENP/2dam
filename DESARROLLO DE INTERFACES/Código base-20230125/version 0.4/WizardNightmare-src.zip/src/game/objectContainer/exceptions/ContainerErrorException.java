package game.objectContainer.exceptions;

public class ContainerErrorException extends Throwable {
}
