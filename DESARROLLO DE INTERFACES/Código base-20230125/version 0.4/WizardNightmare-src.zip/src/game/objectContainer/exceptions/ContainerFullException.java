package game.objectContainer.exceptions;

/**
 * The store is full
 */

public class ContainerFullException extends Throwable {
}
