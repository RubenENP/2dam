package game.character.exceptions;

public class WizardSpellKnownException extends Throwable {
}
