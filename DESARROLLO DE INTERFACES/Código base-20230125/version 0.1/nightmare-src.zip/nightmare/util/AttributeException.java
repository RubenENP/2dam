package nightmare.util;

public class AttributeException extends Throwable {
}
