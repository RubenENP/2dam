package nightmare.items;

import nightmare.spells.Magic_Type;

public class Weapon extends StorableItem{

    public Weapon(int v){
        super(Magic_Type.NO_MAGIC, v);
    }
}
