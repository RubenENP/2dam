package nightmare.items;

import nightmare.spells.Magic_Type;

public class Ring extends StorableItem{

    public Ring(Magic_Type t, int v){
        super(t, v);
    }
}
