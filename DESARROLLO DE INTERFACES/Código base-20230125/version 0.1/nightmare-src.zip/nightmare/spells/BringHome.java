package nightmare.spells;

public class BringHome implements Spell{

    @Override
    public void cast() {

    }
}
