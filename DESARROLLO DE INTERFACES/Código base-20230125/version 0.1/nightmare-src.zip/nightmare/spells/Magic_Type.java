package nightmare.spells;

public enum Magic_Type {NONE, ELECTRICITY, ENERGY, FIRE, LIFE, NO_MAGIC, WIND}
