package nightmare.spells;

public interface Spell {
    //private int nivel;
    //String tipo;

    public void cast();
}
