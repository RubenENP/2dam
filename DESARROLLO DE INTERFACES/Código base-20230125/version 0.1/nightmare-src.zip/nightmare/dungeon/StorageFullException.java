package nightmare.dungeon;

public class StorageFullException extends Throwable {
}
