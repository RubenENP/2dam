package nightmare.dungeon;

public class RoomCrystalEmptyException extends Throwable {
}
