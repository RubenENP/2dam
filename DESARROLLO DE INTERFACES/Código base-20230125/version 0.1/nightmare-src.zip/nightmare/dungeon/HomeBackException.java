package nightmare.dungeon;

public class HomeBackException extends Throwable {
}
