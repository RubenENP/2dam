package nightmare.dungeon;

public class HomeNoSingaException extends Exception {
}
