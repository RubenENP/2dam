package nightmare.management;

public interface DungeonLoader {

     public void load(Demiurge demiurge);
}
