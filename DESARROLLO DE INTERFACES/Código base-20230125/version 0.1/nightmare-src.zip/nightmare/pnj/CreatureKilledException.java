package nightmare.pnj;

public class CreatureKilledException extends Throwable {
}
