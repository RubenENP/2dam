package nightmare.pj;

public class WizardDeathException extends Throwable {
}
