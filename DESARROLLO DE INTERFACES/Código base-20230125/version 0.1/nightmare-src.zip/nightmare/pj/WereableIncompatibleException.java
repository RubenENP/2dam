package nightmare.pj;

public class WereableIncompatibleException extends Throwable {
}
