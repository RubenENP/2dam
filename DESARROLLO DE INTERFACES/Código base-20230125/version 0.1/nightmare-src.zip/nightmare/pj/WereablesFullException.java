package nightmare.pj;

public class WereablesFullException extends Throwable {
}
