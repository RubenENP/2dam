package nightmare.pj;

public class WizardNoWeaponException extends Throwable {
}
