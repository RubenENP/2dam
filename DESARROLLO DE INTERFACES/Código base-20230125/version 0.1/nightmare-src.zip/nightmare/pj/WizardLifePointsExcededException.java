package nightmare.pj;

public class WizardLifePointsExcededException extends Throwable {
}
