package nightmare.pj;

public class WizardTiredException extends Throwable {
}
