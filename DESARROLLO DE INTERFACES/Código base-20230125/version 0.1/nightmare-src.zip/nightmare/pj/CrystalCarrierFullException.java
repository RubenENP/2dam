package nightmare.pj;

public class CrystalCarrierFullException extends Throwable {
}
