package nightmare.pj;

public class WizardNoEnergyException extends Throwable {
}
