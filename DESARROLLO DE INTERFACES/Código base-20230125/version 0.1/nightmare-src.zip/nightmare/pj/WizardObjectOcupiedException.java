package nightmare.pj;

public class WizardObjectOcupiedException extends Throwable {
}
